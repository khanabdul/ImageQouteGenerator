﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Web;

namespace ImageGenerator.Models
{
    public class ImageRequest
    {
        public Color BackColor { get; set; }
        public SizeF imageSize
        {
            get
            {
                return new SizeF(imageSizeWidth, imageSizeHeight);
            }
        }

        public int imageSizeWidth { get; set; }
        public int imageSizeHeight { get; set; }

        public Color TextColor { get; set; }
        public int FontSize { get; set; }
        public string FontStyle { get; set; }
        public string Text { get; set; }
        public int WrapCharLength { get; set; }
    }
}