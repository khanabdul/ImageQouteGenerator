﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Drawing;
using System.Text;
using System.Threading.Tasks;
using ImageGenerator.Models;

namespace ImageGenerator.Controllers
{
    public class ImageGeneratorFactory
    {
        private const int maxFontSize = 40;
        private const int minFontSize = 2;

        public static double AdjutstedHeight { get; private set; }

        public static Image GenerateImage(ImageRequest image)
        {
                //string text = "The following code example demonstrates how to call the Save method. This example is designed to be used with Windows Forms. Create a form that contains a button named Button5. Paste the code into the form, and associate the method";

                string delimiter = Environment.NewLine;
            //int value = Convert.ToInt16(Console.ReadLine());
            int wrapCharLength = image.WrapCharLength!=0?image.WrapCharLength : GetWrapChar(image.Text);
                List<string> textString = WordWrap(image.Text, wrapCharLength);//image.WrapCharLength
            string wrappedText = textString.Aggregate((i, j) => i + delimiter + j);

                Font stringFont = new Font(image.FontStyle, image.FontSize); //new Font("Yu Gothic", 12);
            Color textColor =  image.TextColor; //Color.Black;
            Color backColor = image.BackColor; //Color.LightPink;
                SizeF imageSize = image.imageSize;           //new SizeF(400, 250);
                Image imageNew = DrawText(wrappedText, stringFont, textColor, backColor, imageSize);
            imageNew.Save("c:\\myBitmap.bmp");
            return imageNew;
        }

        private static int GetWrapChar(string text)
        {
            int baseValue = 20;
            if (text.Length < 50)
                return baseValue;
            else
            {
                int approxSentence = (text.Length/50);
               int frontValue = (approxSentence * 4) + baseValue;
                return (frontValue > 58) ? 58 : frontValue;
            }
        }

        private static Image DrawText(String text, Font font, Color textColor, Color backColor, SizeF imageSize)
        {
            //create a new image of the right size
            Image img = new Bitmap((int)imageSize.Width, (int)imageSize.Height);

            Graphics drawing = Graphics.FromImage(img);
            AdjutstedHeight = 20;

            //get adjusted font 
            Font newFont = GetAdjustedFont(drawing, text, font, (int)imageSize.Width - 20,(int)imageSize.Height-20, maxFontSize, minFontSize, true);
            //Font newFont = GetAdjustedFont(drawing, text, font,  new Size((int)imageSize.Width, (int)imageSize.Height));

            //paint the background
            drawing.Clear(backColor);

            //create a brush for the text
            Brush textBrush = new SolidBrush(textColor);

            StringFormat sf = new StringFormat();
            sf.Alignment = StringAlignment.Center;
            sf.LineAlignment = StringAlignment.Center;
            drawing.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
            drawing.PixelOffsetMode = System.Drawing.Drawing2D.PixelOffsetMode.HighQuality;
            drawing.CompositingQuality = System.Drawing.Drawing2D.CompositingQuality.HighQuality;
            drawing.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
            drawing.DrawString(text, newFont, textBrush, 20, (int)AdjutstedHeight);
            drawing.DrawRectangle(new Pen(Brushes.LightGray, 5), new Rectangle(0, 0, img.Width, img.Height));

            drawing.Save();

            textBrush.Dispose();
            drawing.Dispose();

            return img;

        }
        public static List<string> WordWrap(string input, int maxCharacters)
        {
            List<string> lines = new List<string>();

            if (!input.Contains(" ") && !input.Contains("\n"))
            {
                int start = 0;
                while (start < input.Length)
                {
                    lines.Add(input.Substring(start, Math.Min(maxCharacters, input.Length - start)));
                    start += maxCharacters;
                }
            }
            else
            {
                string[] paragraphs = input.Split('\n');

                foreach (string paragraph in paragraphs)
                {
                    string[] words = paragraph.Split(' ');

                    string line = "";
                    foreach (string word in words)
                    {
                        if ((line + word).Length > maxCharacters)
                        {
                            lines.Add(line.Trim());
                            line = "";
                        }

                        line += string.Format("{0} ", word);
                    }

                    if (line.Length > 0)
                    {
                        lines.Add(line.Trim());
                    }
                }
            }
            return lines;
        }
       
        public static Font GetAdjustedFont(Graphics GraphicRef, string GraphicString, Font OriginalFont, int ContainerWidth,int ContainerHeight, int MaxFontSize, int MinFontSize, bool SmallestOnFail)
        {
            // We utilize MeasureString which we get via a control instance           
            for (int AdjustedSize = MaxFontSize; AdjustedSize >= MinFontSize; AdjustedSize--)
            {
                Font TestFont = new Font(OriginalFont.Name, AdjustedSize, OriginalFont.Style);

                // Test the string with the new size
                SizeF AdjustedSizeNew = GraphicRef.MeasureString(GraphicString, TestFont);

                if (ContainerWidth > Convert.ToInt32(AdjustedSizeNew.Width))
                {
                    var fonttobeReturend = OriginalFont.Size <= TestFont.Size ? OriginalFont : TestFont;

                    AdjutstedHeight = (ContainerHeight - AdjustedSizeNew.Height) / 2;

                    if (AdjutstedHeight < 0)
                    {
                        for (int AdjustedSizeH = (int)fonttobeReturend.Size; AdjustedSizeH >= MinFontSize; AdjustedSizeH--)
                        {
                            Font TestFontH = new Font(OriginalFont.Name, AdjustedSizeH, OriginalFont.Style);
                            // Test the string with the new size
                            SizeF AdjustedSizeNewH = GraphicRef.MeasureString(GraphicString, TestFontH);
                            AdjutstedHeight = (ContainerHeight - AdjustedSizeNewH.Height) / 2;
                            if (AdjutstedHeight > 0)
                            {
                                var fonttobeReturendH = fonttobeReturend.Size <= TestFontH.Size ? fonttobeReturend : TestFontH;
                                // Good font, return it
                                return fonttobeReturendH;
                            }
                        }

                    }


                    return fonttobeReturend;
                }

            }
                    // If you get here there was no fontsize that worked
                    // return MinimumSize or Original?
                    if (SmallestOnFail)
            {
                return new Font(OriginalFont.Name, MinFontSize, OriginalFont.Style);
            }
            else
            {
                return OriginalFont;
            }
        }
    }
}