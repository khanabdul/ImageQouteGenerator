﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace ImageGenerator.Controllers
{
    class ProcessMessage
    {
        private static float Maximum = 2;
        private static float countCSK = 1;
        private static float countSRH = 1;
        private Object thisLock = new Object();
        public KeyValuePair<float,float> ProcessMessages(string messagesToProcess)
        {
            float csk = 0, srh = 0;
            lock (thisLock)
            {
                Maximum++;
                if (messagesToProcess == "CSK")
                {
                    countCSK++;
                    Console.WriteLine("CSK :", countCSK);
                     csk = countCSK / Maximum;
                     srh = countSRH / Maximum;
                    //Console.WriteLine("CSK : {0}  ||||||||   SRH : {1}", (csk * 100), (srh * 100));
                }
                if (messagesToProcess == "SRH")
                {
                    countSRH++;
                    Console.WriteLine("SRH :", countSRH);
                     csk = countCSK / Maximum;
                     srh = countSRH / Maximum;
                    //Console.WriteLine("CSK : {0}  ||||||||   SRH : {1}", (csk * 100), (srh * 100));

                }
                return new KeyValuePair<float, float>(csk*100, srh*100);
            }


        }
    }
}