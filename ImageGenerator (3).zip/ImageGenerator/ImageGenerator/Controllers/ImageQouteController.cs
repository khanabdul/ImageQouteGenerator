﻿using ImageGenerator.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Drawing;
using System.Reflection;
using System.IO;
using System.Drawing.Imaging;
using System.Web.Helpers;
using Amazon.SQS;
using Amazon.SQS.Model;
using System.Threading.Tasks;
using System.Drawing.Drawing2D;

namespace ImageGenerator.Controllers
{
    public class ImageQouteController : Controller
    {
        private static string queueUrl = "https://sqs.us-east-1.amazonaws.com/962135731835/SQS_AWS_NEW_Q";//"https://{REGION_ENDPOINT}/queue.|api-domain|/{YOUR_ACCOUNT_NUMBER}/{YOUR_QUEUE_NAME}";
        private static ProcessMessage proc_msg = new ProcessMessage();
        private static KeyValuePair<float, float> kvp = new KeyValuePair<float, float>();
        // GET: ImageQoute
        public ActionResult Index()
        {
            ViewBag.ColorList = GetAllColors();
            ViewBag.FontFamilies = GetFontFamilies();

            return View();
        }


        public ActionResult ImageGenerator(ImageRequest imageRequest)
        {
            imageRequest.TextColor = System.Drawing.Color.FromName(Request.Params["TextColor"]);
            imageRequest.BackColor = System.Drawing.Color.FromName(Request.Params["BackColor"]);
            var image = ImageGeneratorFactory.GenerateImage(imageRequest);
           
            using (var streak = new MemoryStream())
            {
                image.Save(streak, ImageFormat.Png);
                streak.ToArray();
                String file = Convert.ToBase64String(streak.ToArray());
                return Json(file, JsonRequestBehavior.AllowGet);//File(streak.ToArray(), "image/png");
            }
            //return View("Index",);
        }

        private List<Color> GetAllColors()
        {
            List<Color> allColors = new List<Color>();

            foreach (PropertyInfo property in typeof(Color).GetProperties())
            {
                if (property.PropertyType == typeof(Color))
                {
                    allColors.Add((Color)property.GetValue(null));
                }
            }

            return allColors;
        }

        public List<string> GetFontFamilies()
        {
            List<string> fontfamilies = new List<string>();
            foreach (FontFamily family in FontFamily.Families)
            {
                fontfamilies.Add(family.Name);
            }
            return fontfamilies;

        }


        public ActionResult ShowWinner()
        {
            return View();
        }

        public ActionResult getwinner()
        {
            RecieveMessageFromSQSQueue();

            return Json(kvp, JsonRequestBehavior.AllowGet);//File(streak.ToArray(), "image/png");

        }
        public static void ParallelMessagesProcess()
        {
            Parallel.Invoke(
                () => {
                    MessagesRecieve();

                    //PrintCount(-10000, 0);
                },
                () => {
                    MessagesRecieve();
                    //PrintCount(1, 10000);
                },
                () => {
                    MessagesRecieve();
                    //PrintCount(1, 10000);
                }
            );
        }
        private static void MessagesRecieve()
        {
            for (int i = 0; i < 100000; i++)
            {
                RecieveMessageFromSQSQueue();
            }

        }
        private static void RecieveMessageFromSQSQueue()
        {
            //this is the interface to SQS Service
            AmazonSQSClient SQSClient = new AmazonSQSClient();
            ReceiveMessageRequest receiveMessageRequest = new ReceiveMessageRequest();
            receiveMessageRequest.QueueUrl = queueUrl;
            //receiveMessageRequest.WaitTimeSeconds = 20;
            ReceiveMessageResponse receiveMessageResponse = SQSClient.ReceiveMessage(receiveMessageRequest);


            string receiptHandle = string.Empty;
            // receiveMessageResponse.Messages
            if (receiveMessageResponse.Messages.Count != 0)
            {
                foreach (var item in receiveMessageResponse.Messages)
                {
                    //receipt handle to change message visibility timeout or to 


                     kvp =  proc_msg.ProcessMessages(item.Body);
                    //delete the message from the queue
                    receiptHandle = item.ReceiptHandle;
                    DeleteMessage(receiptHandle);
                }
            }


        }
        private static void DeleteMessage(string receiptHandle)
        {
            //this is the interface to SQS Service
            AmazonSQSClient SQSClient = new AmazonSQSClient();

            //delete the message from the queue
            DeleteMessageRequest deleteMessageRequest = new DeleteMessageRequest();

            deleteMessageRequest.QueueUrl = queueUrl;
            deleteMessageRequest.ReceiptHandle = receiptHandle;//"{RECIEPT_HANDLE}";
            DeleteMessageResponse response = SQSClient.DeleteMessage(deleteMessageRequest);
        }



    }
}